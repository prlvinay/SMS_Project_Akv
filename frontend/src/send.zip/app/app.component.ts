import { Component } from '@angular/core';
import { Router, RouterLink, RouterOutlet } from '@angular/router';
import { LoginComponent } from './features/auth/componets/login/login.component';
import { NgIf } from '@angular/common';
import { UserBarComponent } from './features/auth/componets/user-bar/user-bar.component';
import { SideNavigationComponent } from './features/auth/componets/side-navigation/side-navigation.component';
@Component({
  selector: 'app-root',
  imports: [RouterOutlet,NgIf,UserBarComponent,SideNavigationComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent {
  title = 'frontend';

  isAuthenticated: boolean = false;

  constructor(private router: Router) {}

  ngOnInit() {
    this.checkAuthentication();
    this.router.events.subscribe(() => {
      this.checkAuthentication();
    });
  }


  checkAuthentication() {
    if (typeof window !== 'undefined' && localStorage) {
      const token = localStorage.getItem('token');
      this.isAuthenticated = !!token;
    }else{
      console.warn('localStorage is not available.');
    }
  }
}
