import { Routes } from '@angular/router';
import { HomeComponent } from './features/auth/componets/home/home.component';
import { LoginComponent } from './features/auth/componets/login/login.component';
import { RegisterComponent } from './features/auth/componets/register/register.component';
import { DashboardComponent } from './features/auth/componets/dashboard/dashboard.component';

export const routes: Routes = [
  {
    path: "",
    component:HomeComponent
  },
  {
    path: "login",
    component:LoginComponent
  },
  {
    path:'dashboard',
    component:DashboardComponent
  },
  // {
  //   path: "register",
  //   component:RegisterComponent
  // },
  {
    path:'register',
    loadComponent:()=> import('../app/features/auth/componets/register/register.component')
    .then((c)=>c.RegisterComponent)
  },
  {
    "path":"**",
    component:HomeComponent
  }
];
