import { Component, NgModule,Injectable } from '@angular/core';
import {FormsModule, NgForm, NgModel} from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { UserService } from 'src/app/user.service';
@Component({
  selector: 'app-login',
  imports: [FormsModule,CommonModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss',
})


export class LoginComponent {
  username: any;
  password: any;
  remember: any;
  passwordVisible = false;
  loginError = '';

  constructor(private userService: UserService, private router: Router) {}

  onSubmit(form: NgForm) {
    if (!form.valid) {
      this.loginError = 'Please fill out the form correctly.';
      return;
    }

    this.userService.login(form.value.username, form.value.password).subscribe({
      next: (response) => {
        if (response.token && typeof window !== 'undefined') {
          localStorage.setItem('token', response.token);
          alert(response.message);
          form.reset();
          this.router.navigate(['/dashboard']);
        } else {
          this.loginError = 'Login failed. Token not received.';
          this.router.navigate(['/register']);
        }
      },
      error: (error) => {
        this.loginError = error.error.message || 'An error occurred. Please try again.';
      },
    });
  }

  togglePasswordVisibility() {
    this.passwordVisible = !this.passwordVisible;
    const passwordInput: HTMLInputElement = document.getElementById('password') as HTMLInputElement;
    if (passwordInput) {
      passwordInput.type = this.passwordVisible ? 'text' : 'password';
    }
  }
}



// getImgUrl(){
  //   return 'src/assets/images/logo1.png'
  // }
  // getImg: string="https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcTX_DjnC1X_E_YVzz9dlTC1bxscW3IIPDELZYVTmlh74jxUjJAjr-Rf_DwGARyijeahJt2KsHYbcYURlKyAexG78mc8ENIfy56O5hBqKgIl";
  


  // userModel=new User("","",true);
  // onSubmit(form: NgForm) {
  //   if (form.valid) {
  //     console.log('Form Submitted!');
  //     console.log('Username:', this.username);
  //     console.log('Password:', this.password);
  //     console.log('Remember Me:', this.remember);
  //   } else {
  //     console.log('Form is invalid');
  //   }
  // }