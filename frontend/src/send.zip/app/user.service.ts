import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  private apiUrl = 'http://localhost:3000';

  constructor(private http: HttpClient) {}

  login(username: string, password: string) {
    const loginData = { username, password };
    return this.http.post<{ message: string; token?: string }>(
      `${this.apiUrl}/user/login`,
      loginData
    );
  }

  register(formData: any) {
    return this.http.post(`${this.apiUrl}/user/create`, formData);
  }

  getUserDetails() {
    return this.http.get(`${this.apiUrl}/dashboard`, {
      headers: {
        Authorization: `Bearer ${localStorage.getItem('token')}`,
      },
    });
  }
}
